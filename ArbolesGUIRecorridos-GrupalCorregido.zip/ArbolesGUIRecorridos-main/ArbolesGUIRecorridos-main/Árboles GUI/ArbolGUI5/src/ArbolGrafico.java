import javax.swing.*;
import java.awt.*;

public class ArbolGrafico extends JPanel {
    private Arbol arbol;

    public ArbolGrafico(Arbol arbol) {
        this.arbol = arbol;
        setBackground(Color.WHITE); // Fondo blanco
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (arbol == null || arbol.getRaiz() == null) return;

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int panelWidth = getWidth();
        int x = panelWidth / 2;
        int y = 50; // raíz en parte superior
        int separationX = panelWidth / 4;
        int separationY = 70;

        dibujarArbol(g2d, arbol.getRaiz(), x, y, separationX, separationY);
    }

    public void dibujarArbol(Graphics2D g2d, Nodo nodo, int x, int y, int separationX, int separationY) {
        if (nodo == null) return;

        int radio = 20;

        // Coordenadas del nodo
        nodo.x = x;
        nodo.y = y;

        // Dibujar nodo (círculo)
        g2d.setColor(Color.BLACK);
        g2d.fillOval(x - radio, y - radio, 2 * radio, 2 * radio);

        // Etiqueta
        g2d.setColor(Color.WHITE);
        g2d.drawString(nodo.etiqueta, x - 5, y + 5);

        int nextY = y + separationY;

        // IZQUIERDA
        if (nodo.izquierda != null) {
            int childX = x - separationX;
            g2d.setColor(Color.BLACK);
            g2d.drawLine(x, y, childX, nextY);
            dibujarArbol(g2d, nodo.izquierda, childX, nextY, separationX / 2, separationY);
        }

        // CENTRO
        if (nodo.centro != null) {
            int childX = x; // mismo eje X
            g2d.setColor(Color.BLACK);
            g2d.drawLine(x, y, childX, nextY);
            dibujarArbol(g2d, nodo.centro, childX, nextY, separationX / 2, separationY);
        }

        // DERECHA
        if (nodo.derecha != null) {
            int childX = x + separationX;
            g2d.setColor(Color.BLACK);
            g2d.drawLine(x, y, childX, nextY);
            dibujarArbol(g2d, nodo.derecha, childX, nextY, separationX / 2, separationY);
        }
    }
}
