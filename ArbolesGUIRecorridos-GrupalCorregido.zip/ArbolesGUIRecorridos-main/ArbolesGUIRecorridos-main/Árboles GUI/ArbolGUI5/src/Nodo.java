public class Nodo {
    int x, y, z;
    String etiqueta;
    Nodo izquierda, centro, derecha;

    public Nodo(int x, int y,int z, String etiqueta) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.etiqueta = etiqueta;
        this.izquierda = null;
        this.centro = null;
        this.derecha = null;
    }

    @Override
    public String toString() {
        return etiqueta + " (" + x + ", " + y + ", " + z + ")";
    }
}
